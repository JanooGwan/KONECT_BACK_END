package gg.agit.konect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KonectApplicationTests {

    @Test
    void contextLoads() {
    }

}
