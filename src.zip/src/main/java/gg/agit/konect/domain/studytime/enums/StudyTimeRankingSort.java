package gg.agit.konect.domain.studytime.enums;

public enum StudyTimeRankingSort {
    MONTHLY,
    DAILY
}
