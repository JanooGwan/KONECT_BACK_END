package gg.agit.konect.domain.schedule.model;

public enum ScheduleType {
    UNIVERSITY,
    CLUB,
    COUNCIL,
    DORM
}
