package gg.agit.konect.domain.club.dto;

import static io.swagger.v3.oas.annotations.media.Schema.RequiredMode.REQUIRED;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import gg.agit.konect.domain.club.model.Club;
import io.swagger.v3.oas.annotations.media.Schema;

public record ClubFeeInfoResponse(
    @Schema(description = "회비 금액", example = "10000", requiredMode = REQUIRED)
    Integer amount,

    @Schema(description = "은행명", example = "국민은행", requiredMode = REQUIRED)
    String bank,

    @Schema(description = "계좌번호", example = "123-456-7890", requiredMode = REQUIRED)
    String accountNumber,

    @Schema(description = "예금주", example = "BCSD", requiredMode = REQUIRED)
    String accountHolder,

    @Schema(description = "납부 기한", example = "2025.12.31", requiredMode = REQUIRED)
    @JsonFormat(pattern = "yyyy.MM.dd")
    LocalDate deadLine
) {
    public static ClubFeeInfoResponse from(Club club) {
        return new ClubFeeInfoResponse(
            club.getFeeAmount(),
            club.getFeeBank(),
            club.getFeeAccountNumber(),
            club.getFeeAccountHolder(),
            club.getFeeDeadline()
        );
    }
}
