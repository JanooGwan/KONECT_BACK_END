@NonNullApi
@NonNullFields
package gg.agit.konect.global.exception;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
